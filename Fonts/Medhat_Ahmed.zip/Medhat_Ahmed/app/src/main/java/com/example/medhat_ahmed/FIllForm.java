package com.example.medhat_ahmed;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class FIllForm extends AppCompatActivity {

    Button submit_button;
    EditText password_textField;
    EditText confirmPassword_textField;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_f_ill_form);

        password_textField=(EditText) findViewById(R.id.password_textField);
        confirmPassword_textField=(EditText) findViewById(R.id.confirmPassword_textField);

        submit_button=(Button)findViewById(R.id.submit_button);



        submit_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(password_textField.getText().toString().equals(confirmPassword_textField.getText().toString())){
                    submit();
                }
                else{
                    Toast.makeText(FIllForm.this,"INCORRECT PASSWORD",Toast.LENGTH_LONG).show();
                }




            }
        });

    }

    public void submit(){
        Intent intent=new Intent(this,Welcome.class);
        startActivity(intent);
    }
}