package com.example.medhat_ahmed;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class Tab3 extends Fragment{

    Button email_button;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v=inflater.inflate(R.layout.tab3,container,false);

        email_button=(Button)v.findViewById(R.id.email_button);


        email_button.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("IntentReset")
            @Override
            public void onClick(View view) {



                 Intent s=new Intent(Intent.ACTION_SENDTO);
                 s.setData(Uri.parse("mailto:"));
                 s.putExtra(Intent.EXTRA_EMAIL,"mido1998152014@gmail.com");
                 s.putExtra(Intent.EXTRA_TEXT,"WELCOME");
                 startActivity(s);

            }
        });


        return v;
    }
}
